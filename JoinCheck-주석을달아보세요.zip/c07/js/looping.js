$('li em').addClass('seasonal');
//li안에 em태그의 클라스에 seasonal 삽입
$('li.hot').addClass('favorite');
//li 안에 클라스 이름이 hot이면 클라스에 favorite 추가