$(function() {
    var ids = '';
    var $listItems = $('li'); //제이쿼리 셀렉터로 li 선택

    $listItems.on('mouseover click', function() {
        ids = this.id; //ids에 li id가 담김
        //$listItems.children('span').remove(); //처음부터 스팬 태그를 왜 없애 주는지 모르겠음
        $(this).append(' <span class="priority">'+ids+'</span>');
    });

    $listItems.on('mouseout', function() {
        $(this).children('span').remove();
    });
});