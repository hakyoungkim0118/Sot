var $listText = $('ul').text();
$('ul').append('<p>'+ $listText + '</p>');
//ul태그안에 있는 text를 모두 저장후 p태그에 삽입