$(function(){
    var $window = $(window);
    var $slideAd = $('#slideAd');
    var endZone = $('#footer').offset().top - $window.height() - 500;

    $window.on('scroll', function(){

        if((endZone) < $window.scrollTop()){
            $slideAd.animate({'right':'0px'}, 250);
        }else{
            $slideAd.stop(true).animate({'right': '-360px'}, 250);
        }
    });
    //위의 구문들이 어떠한 결과를 내는지 자세하게 알 수 없다.
    //애니메이션처럼 움직일 것이라는 추축은 가능하나, 동작 방식을 알 수 없다.
});