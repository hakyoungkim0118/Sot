var $listHTML = $('ul').html();
$('ul').append($listHTML);//html 태그안에 있는 ul을 복사하여 삽입