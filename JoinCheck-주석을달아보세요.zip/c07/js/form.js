$(function(){

    var $newItemButton = $('#newItemButton');
    var $newItemForm = $('#newItemForm');
    var $textInput = $('input:text');

    $newItemButton.show();
    $newItemForm.hide();

    $('#showForm').on('click',function(){
        $newItemButton.hide(); //버튼이 눌리면 숨기기
        $newItemForm.show(); //버튼이 눌리면 보여주기
    });

    $newItemForm.on('submit',function(e){
        e.preventDefault();
        var newText = $('input:text').val();
       // $('li:list').after('<li>'+newText+'</li>');
        // var textInput = $('input:text').val();
        $('li:last').after('<li>' + newText + '</li>'); //마지막 list 자리에 가서 추가

        $newItemForm.hide(); //리셋
        $newItemButton.show();
        $textInput.val('');
    });
});    