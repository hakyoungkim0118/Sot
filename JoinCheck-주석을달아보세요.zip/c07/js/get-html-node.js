var $listItemHTML = $('li').html();
$('li').append('<i>' + $listItemHTML + '</i>');
//html에 있는 첫 li를 복사한후 삽입