$(function(){
    var $listItems = $('li');

    $listItems.filter('.hot:last').removeClass('hot');//마지막 hot list에서 클라스 hot을 지움 
    $('li:not(.hot)').addClass('cool'); //hot이 아니면 cool 추가
    $listItems.has('em').addClass('complet'); //em태그가 있으면 complet 추가

    $listItems.each(function(){
        var $this = $(this);
        if($this.is('.hot')){
            $this.prepend('우선아이템'); //셀렉터 앞에 추가 
        } 
        
    });
    
    $('li:contains("꿀")').append('(국내산)');//셀렉터 후에 추가
});