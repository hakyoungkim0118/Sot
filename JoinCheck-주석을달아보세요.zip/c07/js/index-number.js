$(function(){
    $('li:lt(2)').removeClass('hot');
    //0번째와 1번째 li의 클라스 hot을 지움
    $('li').eq(0).addClass('complete');
    //인덱스 0번에 클라스 complete 추가
    $('li:gt(2)').addClass('cool');
    //인덱스 2번후의 클라스에 cool을 삽입
});