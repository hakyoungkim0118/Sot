var $listItemText = $('li').text();
$('li').append('<i>' + $listItemText + '</i>');
//처름 li의 모든 text를 저장후 각 li에 i태그와 같이 삽입