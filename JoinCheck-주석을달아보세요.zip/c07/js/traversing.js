$(function(){
    var $h2 = $('h2');
    $('ul').hide(); 
    //ul 태그를 보이지 않게 함
    $h2.append('<a class="show">보이기</a>');
    //h2 태그에 a태그 삽입
    $h2.on('click',function(){
        //ul을 fadein hot 클라스에 complet 더하고 a태그 fadeout
        $h2.next('ul')
        .fadeIn(500)
        .children('.hot')
        .addClass('complete');
        $h2.find('a').fadeOut();
    });
});