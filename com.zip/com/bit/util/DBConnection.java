package com.bit.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * instance가 한번만 만들어 지도록
 */
public class DBConnection {
	private static Connection conn;
	public final static DBConnection instance;
	static {
		instance = new DBConnection();
	}
	public static DBConnection getInstance() {
		return instance;
	}
	private DBConnection() {
		System.out.println("DBConnection");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:admin",user="scott",password="tiger";
			conn = DriverManager.getConnection(url,user,password);
			System.out.println("db connected");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				if(conn != null) {
					conn.close();
				}
			} catch(SQLException ex){
				System.out.println("connection failed");
			}
		} finally {
			// Bak's sugar
		}
	}
	
	public DBConnection(String msg) {
		System.out.println("DBConnection msg");
	}
	
	public static Connection getConnection() {
		return conn;
	}
	
}
