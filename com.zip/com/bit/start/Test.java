package com.bit.start;

import java.sql.Connection;
import java.util.List;

import com.bit.model.dao.EmpInfoRepository;
import com.bit.model.dto_beans.EmpInfo;
import com.bit.util.DBConnection;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn = DBConnection.getConnection();
		System.out.println(conn);
		
		EmpInfoRepository service = new EmpInfoRepository();
		List<EmpInfo> empInfos = service.empInfoAll();
		for(EmpInfo empinfo : empInfos) {
			System.out.println(empinfo);
		}
		
		System.out.println("\n\n");
		EmpInfo empInfo = service.empInfo(7782);
		System.out.println(empInfo);
		
		double total=0,count = 0;
		System.out.println("\n\n");
		empInfos = service.empInfoSal();
		for(EmpInfo empinfo : empInfos) {
			total += empinfo.getSales();
			count++;
			System.out.println(empinfo);
		}
		total = total/count;
		System.out.println("average : "+total);
		
		System.out.println("\n\n");
		empInfos = service.empInfoName();
		for(EmpInfo empinfo : empInfos) {
			System.out.println(empinfo);
		}
	}

}
