package com.bit.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bit.model.dto_beans.EmpInfo;
import com.bit.util.DBConnection;

public class EmpInfoRepository {
	private Connection connection;

	public EmpInfoRepository() {
		connection = DBConnection.getConnection();
	}

	public List<EmpInfo> empInfoAll() {
		List<EmpInfo> temp = null;
		// connection을 통해서 statement 받아서 query를 던져서 받는다
		Statement stmt = null;
		ResultSet rest = null;
		try {
			stmt = connection.createStatement();
			rest = stmt.executeQuery(
					"select emp.empno, emp.ename, dept.dname, dept.loc, emp.job, emp.sal from emp, dept where emp.deptno = dept.deptno");
			temp = new ArrayList<EmpInfo>();
			while (rest.next()) {
				EmpInfo emp = new EmpInfo();
				emp.setEmpNo(rest.getInt(1)); // 0부터 아니고 1부터 시작
				emp.setEmpName(rest.getString("ename"));
				emp.setDeptName(rest.getString("dname"));
				emp.setDeptLocal(rest.getString("loc"));
				emp.setJob(rest.getString("job"));
				emp.setSales(rest.getInt("sal"));
				temp.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return temp;
	}

	public EmpInfo empInfo(int empNo) {
		EmpInfo emp = null;
		Statement stmt = null;
		ResultSet rest = null;
		try {
			stmt = connection.createStatement();
			rest = stmt.executeQuery(
					"select emp.empno, emp.ename, dept.dname, dept.loc, emp.job, emp.sal from emp,dept where emp.deptno=dept.deptno and emp.empno="
							+ empNo);
			while (rest.next()) {
				emp = new EmpInfo();
				emp.setEmpNo(rest.getInt(1)); // 0부터 아니고 1부터 시작
				emp.setEmpName(rest.getString("ename"));
				emp.setDeptName(rest.getString("dname"));
				emp.setDeptLocal(rest.getString("loc"));
				emp.setJob(rest.getString("job"));
				emp.setSales(rest.getInt("sal"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
	}
	
	public List<EmpInfo> empInfoSal() {
		List<EmpInfo> temp = null;
		// connection을 통해서 statement 받아서 query를 던져서 받는다
		Statement stmt = null;
		ResultSet rest = null;
		try {
			stmt = connection.createStatement();
//			rest = stmt.executeQuery(
//					"select emp.empno, emp.ename, dept.dname, dept.loc, emp.job, emp.sal from emp,dept where emp.deptno=dept.deptno and emp.sal>1000");
			temp = new ArrayList<EmpInfo>();
			while (rest.next()) {
				EmpInfo emp = new EmpInfo();
				emp.setEmpNo(rest.getInt(1)); // 0부터 아니고 1부터 시작
				emp.setEmpName(rest.getString("ename"));
				emp.setDeptName(rest.getString("dname"));
				emp.setDeptLocal(rest.getString("loc"));
				emp.setJob(rest.getString("job"));
				emp.setSales(rest.getInt("sal"));
				temp.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return temp;
	}
	
	public List<EmpInfo> empInfoName() {
		List<EmpInfo> temp = null;
		// connection을 통해서 statement 받아서 query를 던져서 받는다
		Statement stmt = null;
		ResultSet rest = null;
		try {
			stmt = connection.createStatement();
//			rest = stmt.executeQuery(
//					"select emp.empno, emp.ename, dept.dname, dept.loc, emp.job, emp.sal from emp,dept where emp.deptno=dept.deptno and emp.ename like '%JAMES%'");
			temp = new ArrayList<EmpInfo>();
			while (rest.next()) {
				EmpInfo emp = new EmpInfo();
				emp.setEmpNo(rest.getInt(1)); // 0부터 아니고 1부터 시작
				emp.setEmpName(rest.getString("ename"));
				emp.setDeptName(rest.getString("dname"));
				emp.setDeptLocal(rest.getString("loc"));
				emp.setJob(rest.getString("job"));
				emp.setSales(rest.getInt("sal"));
				temp.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return temp;
	}
}
