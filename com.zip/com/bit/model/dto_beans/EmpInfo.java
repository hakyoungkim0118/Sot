package com.bit.model.dto_beans;

public class EmpInfo {
	/*
	 * emp > empno ename job sal / dept >dname loc 
	 */
	private int empNo;
	private String empName;
	private String deptName;
	private String deptLocal;
	private String job;
	private int sales;
	
	public EmpInfo() {
		
	}
	
	public EmpInfo(int empNo, String empName, String deptName, String deptLocal, String job, int sales) {
		super();
		this.empNo = empNo;
		this.empName = empName;
		this.deptName = deptName;
		this.deptLocal = deptLocal;
		this.job = job;
		this.sales = sales;
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptLocal() {
		return deptLocal;
	}

	public void setDeptLocal(String deptLocal) {
		this.deptLocal = deptLocal;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getSales() {
		return sales;
	}

	public void setSales(int sales) {
		this.sales = sales;
	}

	@Override
	public String toString() {
		return "EmpInfo [empNo=" + empNo + ", empName=" + empName + ", deptName=" + deptName + ", deptLocal="
				+ deptLocal + ", job=" + job + ", sales=" + sales + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((deptLocal == null) ? 0 : deptLocal.hashCode());
		result = prime * result + ((deptName == null) ? 0 : deptName.hashCode());
		result = prime * result + ((empName == null) ? 0 : empName.hashCode());
		result = prime * result + empNo;
		result = prime * result + ((job == null) ? 0 : job.hashCode());
		result = prime * result + sales;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmpInfo other = (EmpInfo) obj;
		if (deptLocal == null) {
			if (other.deptLocal != null)
				return false;
		} else if (!deptLocal.equals(other.deptLocal))
			return false;
		if (deptName == null) {
			if (other.deptName != null)
				return false;
		} else if (!deptName.equals(other.deptName))
			return false;
		if (empName == null) {
			if (other.empName != null)
				return false;
		} else if (!empName.equals(other.empName))
			return false;
		if (empNo != other.empNo)
			return false;
		if (job == null) {
			if (other.job != null)
				return false;
		} else if (!job.equals(other.job))
			return false;
		if (sales != other.sales)
			return false;
		return true;
	}
	
}
